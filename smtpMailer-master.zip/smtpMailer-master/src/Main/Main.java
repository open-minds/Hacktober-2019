package Main;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import javax.swing.*;
import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class Main extends Application {
        public static Stage stage ;
    @Override
    public void start(Stage primaryStage) throws Exception{
        stage=primaryStage;
        Parent root = FXMLLoader.load(getClass().getResource("Sec.fxml"));
        primaryStage.setTitle("Mailer 1.2");
        primaryStage.setResizable(false);
        primaryStage.setOnCloseRequest(e -> {
            if(JOptionPane.showConfirmDialog(null,"You really wish to close ?","Closing",JOptionPane.YES_NO_OPTION) == 0){
                System.exit(0);
            }
            e.consume();
        });
        primaryStage.setScene(new Scene(root));
        primaryStage.show();
    }


    public static void main(String[] args) {
        launch(args);
        Logger logger = Logger.getLogger("MyLog");
        FileHandler fh;

        try {

            // This block configure the logger with handler and formatter
            fh = new FileHandler();
            logger.addHandler(fh);
            SimpleFormatter formatter = new SimpleFormatter();
            fh.setFormatter(formatter);

            // the following statement is used to log any messages
            logger.info("My first log");

        } catch (SecurityException | IOException e) {
            e.printStackTrace();
        }

        logger.info("Hi How r u?");
    }
}
