package Main;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.FileChooser;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class Controller implements Initializable {
    private static Mailer m = new Mailer();
    private FileChooser fc;
    private static File smtp;
    private static File combo;
    @FXML
    private Label smtPath;
    @FXML
    private Label comboPath;
    @FXML
    private Label crntsmtp ;

    @FXML
    ProgressBar pBar;
    @FXML
    ProgressIndicator pIndc;
    @FXML
    public void EditMsg()throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Sec.fxml"));
        Main.stage.setScene(new Scene(root));
    }
    @FXML
    public void selectsmtp(){
        fc = new FileChooser();
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("Txt","*.txt"));
        smtp = fc.showOpenDialog(null);
        smtPath.setText(smtp.getAbsolutePath());
    }
    @FXML
    public void selectcombo(){
        fc = new FileChooser();
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("Txt","*.txt"));
        combo = fc.showOpenDialog(null);
        comboPath.setText(combo.getAbsolutePath());
    }
    @FXML
    public void proceed(){
        m.readFiles(smtp,combo);
        new Thread(m).start();
    }


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        pBar.progressProperty().bind(m.progressProperty());
        crntsmtp.textProperty().bind(m.messageProperty());
        pIndc.progressProperty().bind(m.progressProperty());
    }
}
