package Main;

import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.scene.control.ProgressBar;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Properties;

public class Mailer extends Task<Void>{

    private Controller c = new Controller();

    private static int smtpcounter = 0;
    private static int mailcounter = 0 ;
    private static ArrayList<Smtp> smtplist = new ArrayList<>();
    private static ArrayList<Email> emailist = new ArrayList<>();
    private static Session session;
    private static boolean connected = false;
    private static boolean prcdclckd = true;

    public static ArrayList<Email> getEmailist() {
        return emailist;
    }

    private static Transport transport;
    private void Smtpchanger(){
        if  (smtpcounter == smtplist.size()-1){
            smtpcounter = 0;
        } else {
            smtpcounter++;
        }
    }

    private void mailcountchecker(){
        if (mailcounter > 10000){
            Smtpchanger();
            mailcounter = 0;
        }
    }
    public void cnct(Properties props) throws MessagingException {
        props.put("mail.smtp.host", smtplist.get(smtpcounter).getHost());
        props.put("mail.smtp.port", smtplist.get(smtpcounter).getPort());
        props.put("mail.smtp.user", smtplist.get(smtpcounter).getUser());
        props.put("mail.smtp.password", smtplist.get(smtpcounter).getPwd());
        props.put("mail.smtp.auth", "true");
        if (smtplist.get(smtpcounter).getPort().equals(String.valueOf(465))) {
            props.put("mail.smtp.starttls.enable", "false");
            props.put("mail.smtp.ssl.enable", "true");
        } else {
            props.put("mail.smtp.ssl.enable", "false");
            props.put("mail.smtp.starttls.enable", "true");
        }
        session = Session.getDefaultInstance(props);
        session.setDebug(true);
        transport = session.getTransport("smtp");
        transport.connect(smtplist.get(smtpcounter).getHost(), smtplist.get(smtpcounter).getUser(), smtplist.get(smtpcounter).getPwd());
    }

    private void hndlcnx(Properties props) {
        while(!connected){
            try {
                cnct(props);
                connected=true;
            } catch (MessagingException e) {
                e.printStackTrace();
                Smtpchanger();
                connected=false;
            }
        }
    }


    public void proceed() {

    }

    public void readFiles(File smFile, File mFile) {
        smtpcounter=0;
        smtplist = new ArrayList<Smtp>();
        mailcounter=0;
        emailist = new ArrayList<Email>();
        connected=false;
        prcdclckd=true;
        try{
            BufferedReader br = new BufferedReader(new FileReader(smFile));
            String line1;
            Smtp smtp ;
            while ((line1 = br.readLine()) != null) {
                if(line1.length()!=0){
                    smtp = new Smtp();
                    String[] sm = line1.split(":");
                    smtp.setHost(sm[0]);
                    smtp.setPort(sm[1]);
                    smtp.setUser(sm[2]);
                    smtp.setPwd(sm[3]);
                    smtplist.add(smtp);
                }
            }
            br = new BufferedReader(new FileReader(mFile));
            Email mail ;
            String line2;
            while ((line2 = br.readLine()) != null) {
                if(line2.length()!=0){
                    mail= new Email();
                    String[] mails = line2.split(":");
                    mail.setEmail(mails[0]);
                    mail.setPwd(mails[1]);
                    emailist.add(mail);
                }
            }
            br.close();
        }catch (IOException | NullPointerException e ){
            JOptionPane.showMessageDialog(null,"Enter Files locations correctly","Error",JOptionPane.INFORMATION_MESSAGE);
        }
    }

    @Override
    protected Void call() throws Exception {
        Properties props = System.getProperties();
        hndlcnx(props);
        while (mailcounter != emailist.size()) {
            try {
                InternetAddress[] toAddress = new InternetAddress[1];
                toAddress[0] = new InternetAddress(emailist.get(mailcounter).getEmail());
                Message message = new MimeMessage(session);
                for( int i = 0; i < toAddress.length; i++) {
                    message.addRecipient(Message.RecipientType.TO, toAddress[i]);
                }
                message.setFrom(new InternetAddress(smtplist.get(smtpcounter).getUser()));
                message.setSubject(" You've been hacked ");//set subject here
                System.out.println(SecController.getFullmsg());
                message.setText(SecController.getFullmsg());//set the text here
                transport.sendMessage(message,toAddress);
                mailcounter++;


                updateMessage(String.valueOf(smtpcounter));
                updateProgress(mailcounter,emailist.size());

                System.out.println(" ");
                System.out.println("************************** Sent **************************");
                System.out.println(" ");

            }catch (MessagingException | IllegalStateException  e) {
                props = System.getProperties();
                connected= false;
                hndlcnx(props);

            }catch (ArrayIndexOutOfBoundsException x){
                x.printStackTrace();
            }
            mailcountchecker();
        }

        System.out.println(" ");
        System.out.println("************************** Done **************************");
        System.out.println(" ");
        JOptionPane.showMessageDialog(null,"Numbers of emails sent succefully are : " +mailcounter +" / "+emailist.size());
        try {
            transport.close();
        } catch (MessagingException e) {
            e.printStackTrace();
        }

        return null;
    }
}