package Main;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

import java.io.IOException;

public class SecController {

    @FXML
    Button done;
    @FXML
    TextField t1,t2,t3,t4;
    private static String Fullmsg;

    public static String getFullmsg() {
        return Fullmsg;
    }
    @FXML
    public void setMsg() throws IOException {
        Fullmsg = t1.getText()+"\n"+t2.getText()+"\n"+t3.getText()+"\n"+t4.getText();
        Parent root = FXMLLoader.load(getClass().getResource("Main.fxml"));
        Main.stage.setScene(new Scene(root));
    }

}
